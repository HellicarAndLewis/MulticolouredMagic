To get the kinect to work you need to install the kinect (freenect) drivers.

they're in the kinect-drivers folder. 

Open device manager and find the kinect XBOX nui items in the list (usually under "other devices")

Right click on each one, and select "Update driver software...", 
choose "Browse my computer for driver software" then on the next screen press the "Browse.." button
and navigate to the "inf" folder inside the "kinect-drivers" folder. You need to do this for
each kinect device in the device manager - "Xbox NUI Audio" "Xbox NUI Camera", and "Xbox NUI Motor"

Then you're done!